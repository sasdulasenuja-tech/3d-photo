import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { SceneObject } from '../services/geminiService';
import * as THREE from 'three';

interface Object3DProps {
  data: SceneObject;
}

export const Object3D: React.FC<Object3DProps> = ({ data }) => {
  const meshRef = useRef<THREE.Mesh>(null);

  // Optional: Add some subtle animation
  useFrame((state) => {
    if (meshRef.current) {
      // meshRef.current.rotation.y += 0.005;
    }
  });

  const getGeometry = () => {
    switch (data.type) {
      case 'box': return <boxGeometry args={[1, 1, 1]} />;
      case 'sphere': return <sphereGeometry args={[0.5, 32, 32]} />;
      case 'cylinder': return <cylinderGeometry args={[0.5, 0.5, 1, 32]} />;
      case 'plane': return <planeGeometry args={[1, 1]} />;
      case 'torus': return <torusGeometry args={[0.5, 0.2, 16, 100]} />;
      default: return <boxGeometry args={[1, 1, 1]} />;
    }
  };

  return (
    <mesh
      ref={meshRef}
      position={data.position}
      scale={data.scale}
      rotation={data.rotation}
    >
      {getGeometry()}
      <meshStandardMaterial color={data.color} />
    </mesh>
  );
};
