import React, { useState, useCallback, useRef, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment, ContactShadows, Float, Text } from '@react-three/drei';
import { Upload, Box, Image as ImageIcon, Loader2, RefreshCw, Maximize2, Camera } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { analyzeImageTo3D, SceneData } from './services/geminiService';
import { Object3D } from './components/Object3D';

export default function App() {
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [sceneData, setSceneData] = useState<SceneData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        setSceneData(null);
        setError(null);
        setIsCameraActive(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
        setImage(null);
        setSceneData(null);
      }
    } catch (err) {
      setError("Could not access camera. Please check permissions.");
      console.error(err);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setImage(dataUrl);
        stopCamera();
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
      setIsCameraActive(false);
    }
  };

  const generate3D = async () => {
    if (!image) return;
    setIsAnalyzing(true);
    setError(null);
    try {
      const data = await analyzeImageTo3D(image);
      setSceneData(data);
    } catch (err) {
      setError("Failed to analyze image. Please try again.");
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const reset = () => {
    setImage(null);
    setSceneData(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white font-sans selection:bg-emerald-500/30">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 px-6 py-4 flex justify-between items-center bg-black/20 backdrop-blur-xl border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <Box className="text-black w-5 h-5" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">Vision3D</h1>
        </div>
        <div className="flex items-center gap-4">
          {image && (
            <button 
              onClick={reset}
              className="px-4 py-2 text-sm font-medium text-white/60 hover:text-white transition-colors flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Reset
            </button>
          )}
        </div>
      </header>

      <main className="pt-24 pb-12 px-6 max-w-7xl mx-auto h-[calc(100vh-2rem)] flex flex-col gap-6">
        {!image && !isCameraActive ? (
          <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center border-2 border-dashed border-white/10 rounded-3xl bg-white/5 hover:bg-white/[0.07] transition-all cursor-pointer group p-12"
              onClick={() => fileInputRef.current?.click()}
            >
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
                accept="image/*" 
                className="hidden" 
              />
              <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Upload className="w-10 h-10 text-emerald-500" />
              </div>
              <h2 className="text-2xl font-semibold mb-2">Upload Photo</h2>
              <p className="text-white/40 max-w-xs text-center">
                Select an image from your device to reconstruct.
              </p>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="flex flex-col items-center justify-center border-2 border-dashed border-white/10 rounded-3xl bg-white/5 hover:bg-white/[0.07] transition-all cursor-pointer group p-12"
              onClick={startCamera}
            >
              <div className="w-20 h-20 bg-blue-500/10 rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Camera className="w-10 h-10 text-blue-500" />
              </div>
              <h2 className="text-2xl font-semibold mb-2">Take Photo</h2>
              <p className="text-white/40 max-w-xs text-center">
                Use your camera to capture a scene in real-time.
              </p>
            </motion.div>
          </div>
        ) : isCameraActive ? (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex-1 relative rounded-3xl overflow-hidden bg-black border border-white/10 flex flex-col items-center justify-center"
          >
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              className="w-full h-full object-cover"
            />
            <canvas ref={canvasRef} className="hidden" />
            <div className="absolute bottom-8 flex gap-4">
              <button 
                onClick={capturePhoto}
                className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-xl hover:scale-110 transition-transform"
              >
                <div className="w-14 h-14 border-2 border-black rounded-full" />
              </button>
              <button 
                onClick={stopCamera}
                className="px-6 py-3 bg-red-500/20 backdrop-blur-md text-red-500 rounded-full font-bold border border-red-500/30"
              >
                Cancel
              </button>
            </div>
          </motion.div>
        ) : (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-6 overflow-hidden">
            {/* Left Panel: Original Image */}
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative rounded-3xl overflow-hidden bg-white/5 border border-white/10 flex flex-col"
            >
              <div className="absolute top-4 left-4 z-10 px-3 py-1 bg-black/50 backdrop-blur-md rounded-full text-xs font-medium text-white/80 border border-white/10 flex items-center gap-2">
                <ImageIcon className="w-3 h-3" />
                Source Image
              </div>
              <div className="flex-1 flex items-center justify-center p-8">
                <img 
                  src={image} 
                  alt="Source" 
                  referrerPolicy="no-referrer"
                  className="max-w-full max-h-full object-contain rounded-xl shadow-2xl"
                />
              </div>
              <div className="p-6 bg-black/40 border-t border-white/5">
                {!sceneData && !isAnalyzing ? (
                  <button 
                    onClick={generate3D}
                    className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-bold rounded-2xl transition-all flex items-center justify-center gap-3 shadow-lg shadow-emerald-500/20"
                  >
                    <Box className="w-5 h-5" />
                    Generate 3D Scene
                  </button>
                ) : isAnalyzing ? (
                  <div className="w-full py-4 bg-white/5 text-white/60 font-medium rounded-2xl flex items-center justify-center gap-3">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Analyzing Image Geometry...
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold uppercase tracking-wider text-white/40">AI Analysis</h3>
                      <button 
                        onClick={generate3D}
                        className="text-emerald-500 text-sm font-medium hover:underline flex items-center gap-1"
                      >
                        <RefreshCw className="w-3 h-3" />
                        Regenerate
                      </button>
                    </div>
                    <p className="text-white/80 leading-relaxed text-sm italic">
                      "{sceneData?.description}"
                    </p>
                  </div>
                )}
              </div>
            </motion.div>

            {/* Right Panel: 3D Scene */}
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="relative rounded-3xl overflow-hidden bg-white/5 border border-white/10 flex flex-col"
            >
              <div className="absolute top-4 left-4 z-10 px-3 py-1 bg-black/50 backdrop-blur-md rounded-full text-xs font-medium text-white/80 border border-white/10 flex items-center gap-2">
                <Box className="w-3 h-3" />
                3D Reconstruction
              </div>
              
              <div className="flex-1 bg-black relative">
                {sceneData ? (
                  <Canvas shadows dpr={[1, 2]}>
                    <Suspense fallback={null}>
                      <PerspectiveCamera makeDefault position={[8, 8, 8]} fov={40} />
                      <OrbitControls 
                        makeDefault 
                        minPolarAngle={0} 
                        maxPolarAngle={Math.PI / 1.75}
                        enableDamping
                        dampingFactor={0.05}
                      />
                      
                      <color attach="background" args={[sceneData.background || '#050505']} />
                      
                      <ambientLight intensity={0.4} />
                      <spotLight position={[10, 15, 10]} angle={0.25} penumbra={1} intensity={1.5} castShadow />
                      <pointLight position={[-10, -10, -10]} intensity={0.5} />
                      
                      <Environment preset="city" />

                      <group position={[0, -1, 0]}>
                        {sceneData.objects.map((obj, idx) => (
                          <Object3D key={idx} data={obj} />
                        ))}
                      </group>

                      <ContactShadows 
                        position={[0, -1, 0]} 
                        opacity={0.6} 
                        scale={20} 
                        blur={2.5} 
                        far={4.5} 
                      />

                      <gridHelper args={[30, 30, 0x444444, 0x222222]} position={[0, -1, 0]} />
                    </Suspense>
                  </Canvas>
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-white/20">
                    {isAnalyzing ? (
                      <div className="flex flex-col items-center gap-4">
                        <div className="relative">
                          <Box className="w-16 h-16 animate-pulse" />
                          <div className="absolute inset-0 border-2 border-emerald-500/50 rounded-lg animate-ping" />
                        </div>
                        <span className="text-sm font-mono uppercase tracking-widest">Building Mesh...</span>
                      </div>
                    ) : (
                      <div className="flex flex-col items-center gap-4">
                        <Box className="w-16 h-16 opacity-20" />
                        <span className="text-sm font-mono uppercase tracking-widest">Awaiting Analysis</span>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {sceneData && (
                <div className="p-4 bg-black/40 border-t border-white/5 flex items-center justify-between">
                  <div className="flex gap-2">
                    {sceneData.objects.map((obj, i) => (
                      <div key={i} className="w-2 h-2 rounded-full" style={{ backgroundColor: obj.color }} title={obj.name} />
                    ))}
                  </div>
                  <span className="text-[10px] font-mono text-white/40 uppercase tracking-tighter">
                    {sceneData.objects.length} Primitives Generated
                  </span>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </main>

      {/* Footer Info */}
      <footer className="fixed bottom-4 left-6 text-[10px] font-mono text-white/20 uppercase tracking-[0.2em] pointer-events-none">
        Vision3D Engine v1.0 // Neural Reconstruction Active
      </footer>

      {/* Error Toast */}
      <AnimatePresence>
        {error && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 left-1/2 -translate-x-1/2 px-6 py-3 bg-red-500/10 border border-red-500/20 backdrop-blur-xl rounded-2xl text-red-400 text-sm font-medium flex items-center gap-3 z-[100]"
          >
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            {error}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
