import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface SceneObject {
  type: 'box' | 'sphere' | 'cylinder' | 'plane' | 'torus';
  position: [number, number, number];
  scale: [number, number, number];
  rotation: [number, number, number];
  color: string;
  name: string;
}

export interface SceneData {
  objects: SceneObject[];
  background: string;
  description: string;
}

export async function analyzeImageTo3D(base64Image: string): Promise<SceneData> {
  const model = "gemini-3.1-pro-preview";
  
  const prompt = `Analyze this image and reconstruct it as a 3D scene using basic geometric primitives (box, sphere, cylinder, plane, torus). 
  Identify the main objects and their spatial relationships. 
  For each object, provide:
  - type: the closest geometric primitive
  - position: [x, y, z] coordinates (keep within -5 to 5 range, y=0 is ground)
  - scale: [width, height, depth]
  - rotation: [x, y, z] in radians
  - color: hex code
  - name: descriptive name
  
  Also provide a general description of the scene and a suitable background color hex code.
  Return the result as a structured JSON object.`;

  const response = await ai.models.generateContent({
    model: model,
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: "image/jpeg",
            data: base64Image.split(',')[1] || base64Image,
          },
        },
        { text: prompt },
      ],
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          objects: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                type: { type: Type.STRING, enum: ['box', 'sphere', 'cylinder', 'plane', 'torus'] },
                position: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                scale: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                rotation: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                color: { type: Type.STRING },
                name: { type: Type.STRING },
              },
              required: ['type', 'position', 'scale', 'rotation', 'color', 'name'],
            },
          },
          background: { type: Type.STRING },
          description: { type: Type.STRING },
        },
        required: ['objects', 'background', 'description'],
      },
    },
  });

  try {
    const text = response.text || '{}';
    // Strip markdown code blocks if present
    const cleanJson = text.replace(/^```json\n?/, '').replace(/\n?```$/, '').trim();
    return JSON.parse(cleanJson) as SceneData;
  } catch (e) {
    console.error("Failed to parse Gemini response", e);
    throw new Error("Failed to generate 3D scene data. The AI returned an invalid format.");
  }
}
